
public class result{
	String nameF = "";
	double scoreF = 0;
	result(String name, Double score){
		nameF = name;
		scoreF = score;
	}
}
